---
name: Question / 使用问题
about: Question about the usage
title: "[Question] 标题"
labels: 'question'
assignees: ''

---

首先通过 issues 的搜索功能，查找这个问题是否已经有过解答。  
首先查看文档中 FAQ，确认这个问题不在常见问题里。  
请仔细描述使用场景、你进行的操作、你期望的表现与实际表现不一致的地方。  

请删除上面的内容并开始描述内容。

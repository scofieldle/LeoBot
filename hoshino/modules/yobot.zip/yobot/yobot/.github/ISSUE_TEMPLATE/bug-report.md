---
name: Bug report / Bug 反馈
about: Create a report to help us improve
title: "[BUG] 标题"
labels: 'bug'
assignees: ''

---

首先通过 issues 的搜索功能，查找这个 bug 是否已经被反馈过。  
请仔细描述这个 bug 是如何出现的，并附上 bug 出现时的截图。（如果网页问题，请附上浏览器控制台错误信息）  
最好能同时附上控制台的报错信息、版本信息。  

请删除上面的内容并开始描述问题。
